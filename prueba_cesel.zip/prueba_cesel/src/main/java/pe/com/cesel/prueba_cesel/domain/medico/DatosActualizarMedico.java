package pe.com.cesel.prueba_cesel.domain.medico;


import jakarta.validation.constraints.NotNull;
import pe.com.cesel.prueba_cesel.domain.direccion.DatosDireccion;

public record DatosActualizarMedico(
        @NotNull Long id,
        String nombre,
        String documento,
        DatosDireccion direccion) {
}
