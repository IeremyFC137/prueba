package pe.com.cesel.prueba_cesel.domain.medico;

import pe.com.cesel.prueba_cesel.domain.direccion.DatosDireccion;

public record DatosRespuestaMedico(
        Long id,
        String nombre,
        String email,
        String telefono,
        String documento,
        DatosDireccion direccion
) {
}
