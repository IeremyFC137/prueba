package pe.com.cesel.prueba_cesel.infra.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfigurations {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity) throws Exception {
        httpSecurity
                .csrf().disable() // If this is deprecated, check for a new method to disable CSRF
                .sessionManagement()
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS); // Check for updates or replacements
                // Add other configurations as needed
                 // This line is an example, adjust according to your needs

        return httpSecurity.build();
    }
}
