package pe.com.cesel.prueba_cesel.domain.usuario;

public record DatosAutenticacionUsuario() {

}
