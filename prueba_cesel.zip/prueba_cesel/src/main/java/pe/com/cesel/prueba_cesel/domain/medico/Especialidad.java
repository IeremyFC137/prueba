package pe.com.cesel.prueba_cesel.domain.medico;

public enum Especialidad {
    ORTOPEDIA,
    CARDIOLOGIA,
    GINECOLOGIA,
    PEDIATRIA
}
