package pe.com.cesel.prueba_cesel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruebaCeselApplicationTests {

	@Test
	void contextLoads() {
	}

}
